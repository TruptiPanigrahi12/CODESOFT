import java.util.Scanner;

public class CurrencyConverter {
    private ExchangeRateAPI exchangeRateAPI;
    private String baseCurrency;
    private String targetCurrency;

    public CurrencyConverter(String baseCurrency, String targetCurrency) {
        this.exchangeRateAPI = new ExchangeRateAPI();
        this.baseCurrency = baseCurrency;
        this.targetCurrency = targetCurrency;
    }

    public void displayMenu() {
        System.out.println("Welcome to the Currency Converter!");
        System.out.println("Base Currency: " + baseCurrency);
        System.out.println("Target Currency: " + targetCurrency);
        System.out.println("Enter the amount in " + baseCurrency + ":");
    }

    public double convertCurrency(double amount) {
        double exchangeRate = exchangeRateAPI.getExchangeRate(baseCurrency, targetCurrency);
        double convertedAmount = amount * exchangeRate;
        return convertedAmount;
    }

    public void displayResult(double amount, double convertedAmount) {
        System.out.println(amount + " " + baseCurrency + " is equivalent to " + convertedAmount + " " + targetCurrency);
    }
}
