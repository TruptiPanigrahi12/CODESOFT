import java.util.HashMap;
import java.util.Map;

public class ExchangeRateAPI {
    // Simulated exchange rates
    private Map<String, Map<String, Double>> exchangeRates;

    public ExchangeRateAPI() {
        // Initialize simulated exchange rates
        exchangeRates = new HashMap<>();
        Map<String, Double> usdRates = new HashMap<>();
        usdRates.put("EUR", 0.82); // 1 USD = 0.82 EUR
        usdRates.put("GBP", 0.72); // 1 USD = 0.72 GBP
        exchangeRates.put("USD", usdRates);

        Map<String, Double> eurRates = new HashMap<>();
        eurRates.put("USD", 1.22); // 1 EUR = 1.22 USD
        eurRates.put("GBP", 0.88); // 1 EUR = 0.88 GBP
        exchangeRates.put("EUR", eurRates);

        Map<String, Double> gbpRates = new HashMap<>();
        gbpRates.put("USD", 1.39); // 1 GBP = 1.39 USD
        gbpRates.put("EUR", 1.14); // 1 GBP = 1.14 EUR
        exchangeRates.put("GBP", gbpRates);
    }

    public double getExchangeRate(String baseCurrency, String targetCurrency) {
        if (exchangeRates.containsKey(baseCurrency) && exchangeRates.get(baseCurrency).containsKey(targetCurrency)) {
            return exchangeRates.get(baseCurrency).get(targetCurrency);
        } else {
            System.out.println("Exchange rate not available for " + baseCurrency + " to " + targetCurrency);
            return 0.0;
        }
    }
}
