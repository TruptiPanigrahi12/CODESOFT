public class Main {
    public static void main(String[] args) {
        CurrencyConverter currencyConverter = new CurrencyConverter("USD", "EUR");

        Scanner scanner = new Scanner(System.in);
        currencyConverter.displayMenu();
        double amount = scanner.nextDouble();

        double convertedAmount = currencyConverter.convertCurrency(amount);
        currencyConverter.displayResult(amount, convertedAmount);

        scanner.close();
    }
}
