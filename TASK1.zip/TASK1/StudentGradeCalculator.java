//STUDENT GRADE CALCULATOR
import java.util.Scanner;

public class StudentGradeCalculator {
    public static void main(String[] args) {
        // Create an instance of the Scanner class for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the number of subjects
        System.out.println("Enter the number of subjects:");
        int numberOfSubjects = scanner.nextInt();

        // Array to store marks for each subject
        int[] marks = new int[numberOfSubjects];

        // Variables to store total marks
        int totalMarks = 0;

        // Prompt the user to enter marks for each subject
        for (int i = 0; i < numberOfSubjects; i++) {
            System.out.println("Enter marks obtained in subject " + (i + 1) + " (out of 100):");
            marks[i] = scanner.nextInt();
            totalMarks += marks[i];
        }

        // Calculate the average percentage
        double averagePercentage = (double) totalMarks / numberOfSubjects;

        // Determine the grade based on the average percentage
        String grade;
        if (averagePercentage >= 90) {
            grade = "A";
        } else if (averagePercentage >= 80) {
            grade = "B";
        } else if (averagePercentage >= 70) {
            grade = "C";
        } else if (averagePercentage >= 60) {
            grade = "D";
        } else {
            grade = "F";
        }

        // Display the results with proper formatting
        System.out.println("Total Marks: " + totalMarks);
        System.out.printf("Average Percentage: %.2f%%\n", averagePercentage);
        System.out.println("Grade: " + grade);

        // Close the scanner
        scanner.close();
    }
}
