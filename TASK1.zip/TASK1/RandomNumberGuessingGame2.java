//3. Compare the user's guess with the generated number and provide feedback on whether the guess
//is correct, too high, or too low.
import java.util.Random;
import java.util.Scanner;

public class RandomNumberGuessingGame2 {
    public static void main(String[] args) {
        // Define the range
        int min = 1;
        int max = 100;

        // Create an instance of the Random class
        Random random = new Random();

        // Generate a random number within the specified range
        int randomNumber = random.nextInt((max - min) + 1) + min;

        // Create an instance of the Scanner class for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter their guess
        System.out.println("Guess a number between " + min + " and " + max + ":");
        int userGuess = scanner.nextInt();

        // Compare the user's guess with the generated number and provide feedback
        if (userGuess == randomNumber) {
            System.out.println("Congratulations! You guessed the correct number.");
        } else if (userGuess < randomNumber) {
            System.out.println("Your guess is too low. The correct number was " + randomNumber + ".");
        } else {
            System.out.println("Your guess is too high. The correct number was " + randomNumber + ".");
        }

        // Close the scanner
        scanner.close();
    }
}
