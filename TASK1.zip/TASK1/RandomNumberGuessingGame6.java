//7. Display the user's score, which can be based on the number of attempts taken or rounds won.

import java.util.Random;
import java.util.Scanner;

public class RandomNumberGuessingGame6 {
    public static void main(String[] args) {
        // Create an instance of the Scanner class for user input
        Scanner scanner = new Scanner(System.in);

        String playAgain;
        int totalScore = 0;
        int roundsPlayed = 0;

        // Loop to allow multiple rounds
        do {
            // Define the range and the number of attempts
            int min = 1;
            int max = 100;
            int maxAttempts = 10;

            // Create an instance of the Random class
            Random random = new Random();

            // Generate a random number within the specified range
            int randomNumber = random.nextInt((max - min) + 1) + min;

            int userGuess = -1;
            int attempts = 0;
            boolean guessedCorrectly = false;

            // Loop until the user guesses the correct number or runs out of attempts
            while (userGuess != randomNumber && attempts < maxAttempts) {
                // Increment the attempts counter
                attempts++;

                // Prompt the user to enter their guess
                System.out.println("Attempt " + attempts + ": Guess a number between " + min + " and " + max + ":");
                userGuess = scanner.nextInt();

                // Compare the user's guess with the generated number and provide feedback
                if (userGuess == randomNumber) {
                    System.out.println("Congratulations! You guessed the correct number.");
                    guessedCorrectly = true;
                } else if (userGuess < randomNumber) {
                    System.out.println("Your guess is too low. Try again.");
                } else {
                    System.out.println("Your guess is too high. Try again.");
                }
            }

            // Calculate the score
            if (guessedCorrectly) {
                totalScore += (maxAttempts - attempts + 1); // Higher score for fewer attempts
            }

            // Check if the user ran out of attempts
            if (!guessedCorrectly) {
                System.out.println("Sorry, you've run out of attempts. The correct number was " + randomNumber + ".");
            }

            // Display the score for this round
            System.out.println("Your score for this round: " + (guessedCorrectly ? (maxAttempts - attempts + 1) : 0));
            roundsPlayed++;

            // Ask the user if they want to play again
            System.out.println("Do you want to play again? (yes/no)");
            playAgain = scanner.next();

        } while (playAgain.equalsIgnoreCase("yes"));

        // Display the final score
        System.out.println("You played " + roundsPlayed + " rounds.");
        System.out.println("Your total score: " + totalScore);

        // Close the scanner
        scanner.close();
    }
}
